package com.epiis.app.controller.reqresp;

import com.epiis.app.generic.ResponseGeneric;

public class ResponsePersonInsert extends ResponseGeneric {}
