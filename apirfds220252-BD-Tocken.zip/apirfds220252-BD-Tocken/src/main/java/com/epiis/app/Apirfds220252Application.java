package com.epiis.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apirfds220252Application {
	public static void main(String[] args) {
		SpringApplication.run(Apirfds220252Application.class, args);
	}
}