package com.epiis.app.apirfds220252;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apirfds220252ApplicationTests {

	@Test
	void contextLoads() {
	}

}
